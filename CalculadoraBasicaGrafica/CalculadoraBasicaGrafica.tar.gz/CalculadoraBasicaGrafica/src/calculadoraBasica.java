/**
 * Esta es la clase principal, donde se manda a llamar todo el programa
 * @author primo
 * @version 1.0 06/10/2015
 */
public class calculadoraBasica {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Vista.ejecutar();
    }
    
}
